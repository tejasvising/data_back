from flask import Flask, render_template, request
import tensorflow as tf
from tensorflow.keras.preprocessing import image
import numpy as np

# Import the model
model = tf.keras.models.load_model("model.h5")

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            img = image.load_img(file, target_size=(512, 512))
            img = image.img_to_array(img)
            img = np.expand_dims(img, axis=0)
            img = img / 255.0  # Normalize
            
            # Make prediction
            prediction = model.predict(img)
            if prediction[0][0] > 0.5:
                result = "Steganographic content detected."
            else:
                result = "No steganographic content detected."

            return render_template('result.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
